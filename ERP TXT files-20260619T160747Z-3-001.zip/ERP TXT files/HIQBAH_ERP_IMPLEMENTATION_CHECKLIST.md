════════════════════════════════════════════════════════════════════════════════
                                                                                
              HIQBAH ERP — IMPLEMENTATION ROADMAP CHECKLIST                     
                                                                                
              قائمة المهام التنفيذية الشاملة                                     
                                                                                
════════════════════════════════════════════════════════════════════════════════

This document is the actionable implementation checklist for building the
Hiqbah ERP. Every item is a concrete task that can be assigned, tracked,
and ticked off as work progresses.

How to use:
  - Items are organised in phases following the recommended build order.
  - Each task has [ ] (todo), [~] (in progress), or [x] (done) marker.
  - Tasks marked 🔴 CRITICAL must be completed before dependent tasks start.
  - Tasks marked 🟡 HIGH-PRIORITY should be prioritised within a phase.
  - Tasks marked 📐 ARCHITECTURE require architectural decisions before coding.
  - References to module documents are in [brackets].

Audience: Engineering Lead, Developers, QA, DevOps, Product Manager.

Source: Distilled from 26 module documents + Master Document Part 4.



════════════════════════════════════════════════════════════════════════════════
              PHASE 0 — FOUNDATIONS (BEFORE ANY MODULE CODE)
════════════════════════════════════════════════════════════════════════════════

These items MUST be in place before any module work begins. Skipping or
delaying these creates architectural debt that becomes expensive to fix later.


┌─────────────────────────────────────────────────────────────────────────────┐
│  0.1  INFRASTRUCTURE SETUP                                                  │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Set up production-grade database (PostgreSQL recommended)
       [ ] Configure row-level security (RLS) capability
       [ ] Set up automated daily backups with point-in-time recovery
       [ ] Configure read replicas (Phase 2 readiness)

  [ ] 🔴 Set up tenant-scoped file storage
       [ ] S3-compatible object storage (S3, MinIO, or DigitalOcean Spaces)
       [ ] Tenant-scoped bucket/path strategy
       [ ] Short-TTL pre-signed URLs for file access

  [ ] 🔴 CI/CD pipeline
       [ ] Source control (Git) + branching strategy
       [ ] Automated test runner (unit + integration)
       [ ] Deploy-to-staging on merge to main
       [ ] Manual deploy-to-production with rollback capability

  [ ] 🔴 📐 Module Boundary Linter [File B §4.8]
       *** THIS IS THE #1 ARCHITECTURE INVESTMENT ***
       [ ] Define module folder structure
       [ ] Configure linter to detect cross-module imports
       [ ] Linter runs in CI; PR rejected if violations exist
       [ ] Document the boundary rules for the team

  [ ] Monitoring and observability
       [ ] Application logs (structured JSON)
       [ ] Performance monitoring (response times, error rates)
       [ ] Database query monitoring
       [ ] Alert thresholds for critical paths

  [ ] Environment configuration
       [ ] Secret management (no secrets in code)
       [ ] Environment-specific configs (dev/staging/prod)
       [ ] Feature flag service infrastructure


┌─────────────────────────────────────────────────────────────────────────────┐
│  0.2  AUTHENTICATION & USER MANAGEMENT (File 01)                            │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Design data model
       [ ] User (global, no tenant scope)
       [ ] UserTenantMembership (the multi-tenant bridge from day 1)
       [ ] Session, SessionDevice
       [ ] Role, Permission, RolePermission
       [ ] LoginAttempt, MFAEnrollment, PinSetup
       [ ] InvitationToken, PasswordResetToken
       [ ] DeviceRegistration

  [ ] 🔴 Implement authentication endpoints
       [ ] POST /v1/auth/login (password + MFA challenge)
       [ ] POST /v1/auth/mfa/setup, /verify
       [ ] POST /v1/auth/refresh
       [ ] POST /v1/auth/logout
       [ ] POST /v1/auth/password-reset/request, /confirm

  [ ] 🔴 Implement PIN unlock
       [ ] POST /v1/auth/pin-unlock (only on REGISTERED device)
       [ ] First login on new device requires full credentials
       [ ] Brute force protection (3 fails → lockout, 5 fails → require password)

  [ ] 🟡 Invitation-based account creation
       [ ] POST /v1/auth/invitations (Tenant Admin only)
       [ ] POST /v1/auth/invitations/accept
       [ ] Token expiry (default 7 days)

  [ ] 🔴 Session and token management
       [ ] Bearer token validation middleware
       [ ] Session resolution: tenant_id, user_id, permissions from token
       [ ] GET /v1/auth/sessions (active sessions for current user)
       [ ] DELETE /v1/auth/sessions/{id} (log out other devices)
       [ ] Token refresh flow

  [ ] 🔴 source_interface tracking
       [ ] Every API call records source: WEB | iOS | ANDROID | STATION | API | SYSTEM
       [ ] Stored on every audit log entry
       [ ] Available in every service method context

  [ ] 🔴 MFA mandatory for sensitive roles
       [ ] List of roles requiring MFA: TENANT_ADMIN, FINANCE_MANAGER, CEO,
            QUALITY_MANAGER, HR_MANAGER
       [ ] Block access until MFA enrolled for these roles
       [ ] TOTP-based MFA (Google Authenticator compatible)

  [ ] Security hardening
       [ ] Password complexity rules
       [ ] Account lockout after N failed attempts
       [ ] Unusual login alerts (new device, new IP)
       [ ] Password reset token single-use


┌─────────────────────────────────────────────────────────────────────────────┐
│  0.3  EXTENSION ARCHITECTURE INFRASTRUCTURE (File B)                        │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 📐 AuditLogService
       [ ] Define AuditLog entity schema
       [ ] INSERT-only at database level (revoke UPDATE/DELETE grants)
       [ ] log(action_type, entity_type, entity_id, user_id, before, after, context)
       [ ] Source interface tracked on every entry
       [ ] Synchronous, blocking (failure aborts the calling operation)
       [ ] Configurable retention (default: 7 years for financial, indefinite for security)

  [ ] 🔴 📐 NotificationService
       [ ] sendPush(user_id, message, payload) → push to mobile
       [ ] sendEmail(user_id, template, variables) → email delivery
       [ ] sendInApp(user_id, message, action_url) → in-app notifications
       [ ] Deduplication: same notification per same event within cooldown
       [ ] Templates externalised (per tenant)

  [ ] 🔴 📐 EventBus with Outbox Pattern
       [ ] Define Event schema (event_type, payload, tenant_id, timestamp)
       [ ] Outbox table (per emitting module or central)
       [ ] Background publisher polls outbox and publishes
       [ ] Subscriber registration mechanism
       [ ] Idempotent consumer support (idempotency_key)
       [ ] Retry with exponential backoff on consumer failure
       [ ] Dead letter queue for unrecoverable failures

  [ ] 🔴 FeatureFlagService
       [ ] isEnabled(tenant_id, feature_key) → boolean
       [ ] Per-tenant feature configuration
       [ ] Cached for performance
       [ ] Admin UI for enabling/disabling

  [ ] 🔴 📐 ApprovalWorkflowService (skeleton — populated when File 08 ready)
       [ ] ApprovalRequest entity
       [ ] createRequest() endpoint
       [ ] approve() / reject() endpoints
       [ ] Notification integration on creation
       [ ] Escalation logic (configurable timeout)
       [ ] Status tracking and history

  [ ] InternalAction layer [File B §4.6]
       [ ] InternalAction entity for cross-module orchestration
       [ ] Compensating action pattern for rollback
       [ ] Action history and replay capability


┌─────────────────────────────────────────────────────────────────────────────┐
│  0.4  AUTHORITY MATRIX SUBSECTION (File 08, partial)                        │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 AuthorityMatrixRule entity
       [ ] tenant_id, rule_code, action_type, threshold_operator,
            threshold_value, threshold_unit
       [ ] primary_approver_role, secondary_approver_role
       [ ] requires_dual_approval, self_approval_allowed
       [ ] escalation_role, escalation_hours
       [ ] is_active, effective_from, effective_to

  [ ] 🔴 AuthorityMatrixService.resolveApprover()
       [ ] Hot path: < 20ms response requirement
       [ ] In-memory cache per tenant (5-min TTL)
       [ ] Cache invalidation on rule update
       [ ] Returns required_approver_role + dual_approval flag

  [ ] 🔴 Authority Matrix admin UI
       [ ] List rules
       [ ] Create/edit rules (TENANT_ADMIN only)
       [ ] Audit log every modification (before/after)
       [ ] Import from Excel template (accelerates onboarding)

  [ ] 🔴 Onboarding wizard for Authority Matrix
       [ ] Step in tenant onboarding: configure matrix
       [ ] Standard matrix template (25 rules from Master §3.3)
       [ ] Alert if <10 rules after 14 days of activity

  [ ] 🔴 Integration with ApprovalWorkflowService
       [ ] ApprovalWorkflowService.createRequest() calls AuthorityMatrixService.resolveApprover()
       [ ] Self-approval check (requester ≠ approver)
       [ ] Escalation timer setup


┌─────────────────────────────────────────────────────────────────────────────┐
│  0.5  ACCOUNTING FOUNDATIONS (File 02, partial)                             │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 ChartOfAccounts entity
       [ ] Hierarchical structure (account_code, parent_account_id)
       [ ] Account types: ASSET, LIABILITY, EQUITY, REVENUE, EXPENSE
       [ ] Standard chart for Saudi business (template)

  [ ] 🔴 JournalEntry + JournalEntryLine entities
       [ ] Status lifecycle: DRAFT → POSTED → (immutable)
       [ ] Database-level INSERT-only on POSTED entries
       [ ] Balanced entry validation (Dr = Cr)
       [ ] Reversal mechanism (creates new REVERSAL entry, original preserved)

  [ ] 🔴 Outbox Pattern integration
       [ ] Outbox table for accounting events
       [ ] Atomic write of operational change + accounting event
       [ ] Background publisher processes outbox

  [ ] 🔴 TaxConfiguration
       [ ] VAT 15% standard rate (Saudi)
       [ ] Zero-rated configuration option
       [ ] Tax category per product



════════════════════════════════════════════════════════════════════════════════
              PHASE 1 — CORE OPERATIONS (THE OPERATIONAL ERP FOUNDATION)
════════════════════════════════════════════════════════════════════════════════


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.1  COFFEE LIFECYCLE (Files 03+04+05 Consolidated)                        │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 SampleArrival entity (no inventory impact)
       [ ] supplier_id, origin, weight_g, arrived_at
       [ ] No InventoryLedgerMovement on creation

  [ ] 🔴 SampleRoastBatch entity
       [ ] sample_roast = true ALWAYS
       [ ] Unit test: completion produces ZERO inventory movements
       [ ] Master Invariant 4 enforcement

  [ ] 🔴 CuppingSession + CuppingScore entities
       [ ] SCA-standard attributes
       [ ] One score per cupper per sample per session
       [ ] Server-side score computation (never client-submitted final)
       [ ] Test with known SCA reference scores

  [ ] 🔴 CuppingSession lifecycle
       [ ] DRAFT → SCORING → CLOSED with decision
       [ ] decision: PURCHASE_APPROVED | HOLD | REJECTED
       [ ] Coffee Director approves PURCHASE_APPROVED

  [ ] 🔴 GreenCoffeePurchaseOrder entity
       [ ] Purchase Order Gate: requires linked CuppingSession with
            decision = PURCHASE_APPROVED
       [ ] Service-layer validation; hard rejects without cupping

  [ ] 🔴 GoodsReceipt entity
       [ ] Status lifecycle: PENDING → INSPECTING → COMPLETED
       [ ] Cannot advance to COMPLETED without ArrivalSampleMatchRecord

  [ ] 🔴 ArrivalSampleMatchRecord
       [ ] result: ACCEPTED | REJECTED
       [ ] Goods Receipt Gate: completion requires ACCEPTED match

  [ ] 🔴 GreenCoffeeLot entity with lot_sn
       [ ] lot_sn generation: format LOT-YYYY-NNNNN (sequential per tenant)
       [ ] lot_sn IMMUTABLE after creation
       [ ] NOT NULL constraint in all downstream entity tables
       [ ] Master Invariant 12 enforcement

  [ ] 🔴 LotQualityHistory entity
       [ ] APPEND-ONLY (no updates, no deletes)
       [ ] Every quality event linked to lot_sn
       [ ] Forensic query: GET /coffee/lots/{lot_sn}/history

  [ ] Lot status lifecycle
       [ ] FRESH → AGING → EXPIRED
       [ ] UNDER_INVESTIGATION (on QC failures)
       [ ] CLOSED (end of life)

  [ ] Transformation handling [Master Invariant 6]
       [ ] POST /coffee/lots/{lot_sn}/transform
       [ ] Creates new lot with new lot_sn
       [ ] Source lot deducted from inventory
       [ ] Transformation does NOT count as new production


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.2  RECIPE LIBRARY (File 25)                                              │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Recipe + RecipeVersion entities
       [ ] Per bean+lot+brew_method combination
       [ ] Versioning (new version, never overwrite)
       [ ] Status: DRAFT → REVIEW → PUBLISHED → SUPERSEDED

  [ ] 🔴 PublishedRecipeValues table
       [ ] INSERT-only at database level
       [ ] Master Invariant 13 enforcement
       [ ] Database test: UPDATE/DELETE attempts produce error

  [ ] 🔴 getOfficialRecipe() service (HOT PATH)
       [ ] Response time < 100ms
       [ ] In-memory cache with event-driven invalidation
       [ ] Called by every CalibrationSession creation

  [ ] 🔴 Recipe publication workflow
       [ ] Coffee Director creates DRAFT
       [ ] Submit for review
       [ ] Quality Manager / Coffee Director publishes
       [ ] Previous version superseded automatically
       [ ] UNIQUE constraint: one PUBLISHED per (tenant, bean, lot, brew_method)

  [ ] Recipe browser UI
       [ ] Library view (all recipes for tenant)
       [ ] Version history per recipe
       [ ] Read-only access for baristas


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.3  PRICING MODULE (File 10)                                              │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Price list entities
       [ ] WholesalePriceList (B2B with volume tiers)
       [ ] RetailPriceList (B2C per SKU)
       [ ] effective_from, effective_to date ranges
       [ ] approved_by tracking

  [ ] 🔴 CustomerPriceOverride entity
       [ ] Per (customer_id, product_id) override
       [ ] Mandatory reason field
       [ ] No overlap for same customer+product (constraint)
       [ ] Override > 15% below standard requires Authority Matrix approval

  [ ] 🔴 DiscountRule entity
       [ ] Types: SEASONAL, VOLUME, CUSTOMER_TIER, COUPON, PROMOTIONAL
       [ ] Methods: PERCENTAGE, FIXED_AMOUNT
       [ ] Maximum cap (prevents 100% discount mistakes)
       [ ] Authority Matrix integration (>10% requires approval)
       [ ] Atomic coupon usage_count increment (SELECT FOR UPDATE)

  [ ] 🔴 PriceResolutionService (HOT PATH)
       [ ] Response time < 50ms
       [ ] Resolves price hierarchy in order:
            Level 1: CustomerPriceOverride
            Level 2: Volume tier price
            Level 3: Channel price list
            Level 4: Base product price
       [ ] DiscountEngine evaluates after price resolution
       [ ] Returns: resolved_price + discount info
       [ ] In-memory cache with event-driven invalidation

  [ ] 🔴 PriceChangeLog (immutable)
       [ ] INSERT-only at database level
       [ ] Every change recorded with before/after + reason
       [ ] Database test: UPDATE/DELETE attempts fail

  [ ] 🔴 BELOW_COST validation
       [ ] Compare resolved_price to current cost layer
       [ ] BELOW_COST alert if price < cost
       [ ] Finance Manager approval required to proceed
       [ ] Master Invariant 10 enforcement

  [ ] Price list export
       [ ] PDF (branded wholesale price list)
       [ ] Excel
       [ ] WhatsApp-ready text format
       [ ] All exports logged with user identity


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.4  SALES MODULE (File 16)                                                │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Customer + CustomerContact entities
       [ ] payment_terms (PREPAYMENT | NET_30 | NET_60 | CUSTOM)
       [ ] credit_limit
       [ ] Status: ACTIVE | INACTIVE | BLOCKED

  [ ] 🔴 SalesRep entity
       [ ] Linked to User account
       [ ] mobile_number, base_branch

  [ ] 🔴 ClientAssignment entity
       [ ] Per (customer_id, rep_id) with split_percentage
       [ ] DATABASE CONSTRAINT: sum of split_percentage per customer = 100
       [ ] Effective date ranges

  [ ] 🔴 Lead + LeadActivity entities
       [ ] Pre-customer pipeline tracking
       [ ] Conversion to Customer preserves history
       [ ] Lead aging alerts

  [ ] 🔴 CommissionConfiguration entity
       [ ] Per rep + customer-tier + product-category
       [ ] Commission rate (%)
       [ ] effective_from, effective_to

  [ ] Sales Rep mobile app foundations
       [ ] Customer list with last-order context
       [ ] Lead capture form
       [ ] Visit/activity logging
       [ ] Commission view (own only)
       [ ] AR follow-up reminders
       [ ] Offline support (idempotency keys for submissions)

  [ ] Collection task management
       [ ] CollectionTask per overdue invoice
       [ ] Auto-generated from AR aging
       [ ] Rep mobile reminders


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.5  ORDER WORKFLOW (File 06)                                              │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 SalesOrder + SalesOrderLine entities
       [ ] Full status lifecycle: DRAFT → PENDING_PAYMENT → CONFIRMED →
            IN_PRODUCTION → PACKAGED → SHIPPED → DELIVERED → CLOSED
       [ ] Alternative: ON_HOLD | CANCELLED
       [ ] Order code generation (sequential per tenant)

  [ ] 🔴 Price validation at line creation
       [ ] Server-side: compare submitted price to PriceResolutionService output
       [ ] Mismatch beyond tolerance → Special Price Request workflow
       [ ] Master Invariant 10 enforcement

  [ ] 🔴 InventoryReservation entity
       [ ] Atomic creation on order confirmation
       [ ] Reduces available_quantity
       [ ] Released atomically on order cancellation
       [ ] Reconciliation job (nightly): active reservations vs. active orders

  [ ] 🔴 CommissionRecord entity (INSERT-ONLY)
       [ ] Created at order confirmation
       [ ] Snapshot of ClientAssignment percentages AT THAT TIME
       [ ] Commission on VAT-EXCLUSIVE subtotal
       [ ] Database test: UPDATE attempts fail

  [ ] 🔴 OrderShipped event firing
       [ ] Fires when status transitions to SHIPPED
       [ ] Outbox pattern (atomic with status change)
       [ ] Accounting subscribes for COGS recognition (Master Invariant 5)

  [ ] 🔴 ShipmentRecord entity
       [ ] Per shipment (partial shipments supported)
       [ ] Tracking number, carrier
       [ ] Shipped_at timestamp

  [ ] 🔴 Payment confirmation gate
       [ ] CONFIRMED status requires PaymentConfirmed event for new customers
       [ ] Or credit check passes for established customers
       [ ] Default new customer payment_terms = PREPAYMENT

  [ ] Idempotency support for rep submissions
       [ ] idempotency_key on order creation API
       [ ] Same key = same order returned (no duplicates)
       [ ] 24-hour idempotency window

  [ ] OrderStatusHistory (append-only)
       [ ] Every status transition recorded
       [ ] Who, when, reason


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.6  ACCOUNTING MODULE FULL (File 02)                                      │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Invoice + InvoiceLine entities
       [ ] Status: DRAFT → POSTED → (immutable)
       [ ] Sequential invoice number per tenant
       [ ] VAT calculated at posting (15% standard or zero-rated)
       [ ] ZATCA Phase 1 fields (seller VAT, buyer info, line-level tax)

  [ ] 🔴 OrderShipped → COGS handler [Master Invariant 5]
       [ ] Subscribes to OrderShipped event
       [ ] Posts: Dr COGS / Cr Inventory
       [ ] Uses weighted average cost at time of shipment
       [ ] Integration test: order in CREATED status produces NO COGS entry

  [ ] 🔴 Payment + PaymentAllocation entities
       [ ] Record customer payments
       [ ] Allocate to specific invoices
       [ ] Customer Advance handling [Master Invariant 6 in File 02]
            Payment without allocated order → Customer Advance liability
            Allocated to order at order completion

  [ ] 🔴 Customer Advance handling (critical compliance)
       [ ] Deposit without order: Dr Cash / Cr Customer Advance (liability)
       [ ] Order ships: move from Advance to Revenue
       [ ] NEVER recognised as revenue prematurely
       [ ] Code-enforced; unit-tested

  [ ] Expense + ExpenseReimbursement entities
       [ ] Per category
       [ ] > 500 SAR requires Finance Manager approval (Authority Matrix AM-025)

  [ ] AR Aging view (computed)
       [ ] Per customer, age buckets (0-30, 31-60, 61-90, 90+)
       [ ] Feeds collection tasks

  [ ] AP Aging view (computed)

  [ ] Weighted average inventory costing
       [ ] Recompute on each goods receipt at different cost
       [ ] Cost layer per SKU per tenant

  [ ] Financial reports (used by File 15)
       [ ] P&L
       [ ] Balance Sheet
       [ ] Cash Position
       [ ] AR/AP aging detail
       [ ] All filter status = POSTED only [Master Invariant 7]


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.7  INVENTORY OPERATIONS + PERIODIC COUNT (File 20)                       │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Inventory ledger entities
       [ ] InventoryLedgerEntry (append-only event log of movements)
       [ ] InventoryBalance (computed view per SKU per location)
       [ ] Balances always derivable from ledger

  [ ] 🔴 Available vs. Reserved vs. On-Hand
       [ ] On-Hand = ledger balance
       [ ] Reserved = active InventoryReservation total
       [ ] Available = On-Hand - Reserved
       [ ] Sales availability checks use Available

  [ ] 🔴 InventoryCountSession (File 20)
       [ ] Status lifecycle: PLANNED → COUNTING → COMPLETED → POSTED
       [ ] Book balance snapshot at session creation (REPEATABLE READ)

  [ ] 🔴 Counting workflow
       [ ] Counter records what they SEE (book balance NOT shown during counting)
       [ ] InventoryCountEntry per SKU
       [ ] InventoryVariance computed after counting

  [ ] 🔴 Dual approval for variance > 5% [Authority Matrix AM-008]
       [ ] Finance Manager + Operations Manager
       [ ] Cannot post adjustment without both approvals

  [ ] 🔴 Atomic adjustment posting
       [ ] Single database transaction:
            - Inventory ledger entries
            - Accounting variance entry (Dr/Cr Inventory Adjustment)
            - Audit log
            - Session status → COMPLETED
       [ ] All-or-nothing


┌─────────────────────────────────────────────────────────────────────────────┐
│  1.8  HR MODULE (File 17 — Phase 1)                                         │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 EmployeeProfile entity
       [ ] Personal data + employment data
       [ ] Status: ACTIVE | ON_LEAVE | TERMINATED | ON_BOARDING

  [ ] 🔴 EmployeeContract entity (VERSIONED)
       [ ] New contract = new record (never overwrite)
       [ ] Previous contract → status = SUPERSEDED
       [ ] Active contract = most recent ACTIVE

  [ ] 🔴 EmployeeDocument entity
       [ ] Iqama, passport, certificates
       [ ] expiry_date tracking
       [ ] Alerts: 30 / 14 / 7 / 1 day before expiry

  [ ] 🔴 EmployeeTimeline (append-only)
       [ ] Every employment event: hire, promotion, salary change, transfer,
            leave, termination
       [ ] Cannot be modified or deleted

  [ ] Shift + ShiftAssignment + ShiftSchedule
       [ ] Per branch per period

  [ ] AttendanceRecord (per employee per day)
       [ ] check_in, check_out
       [ ] Manual entry or biometric (Phase 2)

  [ ] LeaveType + LeaveRequest + LeaveBalance
       [ ] Annual, sick, emergency
       [ ] Approval workflow via Authority Matrix (AM-023)

  [ ] 🔴 PayrollRun + PayrollLineItem
       [ ] Compute → Approve → Post lifecycle
       [ ] Master Invariant 15: BLOCK if any employee has negative net
       [ ] Authority Matrix AM-014 (Finance Manager approval)
       [ ] PayrollApproved event → Accounting posts salary expense

  [ ] 🔴 Manual GOSI entry (Phase 1)
       [ ] Phase 2: automated GOSI calculation
       [ ] Configurable per employee

  [ ] PerformanceReview + PerformanceGoal
       [ ] Per period
       [ ] Linked to OKR Key Results (Phase 4)

  [ ] TrainingSession + TrainingAttendance



════════════════════════════════════════════════════════════════════════════════
              PHASE 2 — QUALITY & OPERATIONAL EXCELLENCE
════════════════════════════════════════════════════════════════════════════════


┌─────────────────────────────────────────────────────────────────────────────┐
│  2.1  DAILY CALIBRATION (File 19)                                           │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 CalibrationSession entity (shared with File 09)
       [ ] visit_type discriminator: NULL (daily) | FIELD_VISIT (from File 09)
       [ ] branch_id, equipment_id, bean_lot_sn
       [ ] official_recipe_snapshot (FROZEN at session creation)
       [ ] Status: DRAFT → IN_PROGRESS → SUBMITTED → UNDER_REVIEW → APPROVED

  [ ] 🔴 CalibrationShot entity
       [ ] Dose, Grind Setting, Time, Yield, TDS, Extraction%
       [ ] Sensory: Acidity, Finish, Balance (1-5)
       [ ] Extraction% = (TDS × Yield) / Dose (server-computed)

  [ ] 🔴 ExtractionDiagnosticEngine (PURE FUNCTION)
       [ ] No state, no side effects
       [ ] Inputs: shot data + target recipe values
       [ ] Outputs: diagnostic + suggested adjustment + confidence
       [ ] Unit-testable with known scenarios

  [ ] 🔴 Best shot designation
       [ ] One per session
       [ ] Used for Recipe Intelligence aggregation

  [ ] 🔴 Session approval workflow
       [ ] Authority Matrix routing (Quality Manager or Branch Manager per matrix)
       [ ] APPROVED → fires CalibrationSessionApproved event

  [ ] 🔴 Equipment status integration
       [ ] EquipmentStatusChanged event consumer
       [ ] Suppress calibration tasks for UNDER_MAINTENANCE equipment

  [ ] NO_OFFICIAL_RECIPE mode
       [ ] When no PUBLISHED recipe exists for bean
       [ ] Calibration proceeds without comparison
       [ ] Data still aggregated for Recipe Intelligence


┌─────────────────────────────────────────────────────────────────────────────┐
│  2.2  CALIBRATION WASTE (File 22)                                           │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 CalibrationWasteRecord entity
       [ ] UNIQUE constraint on calibration_session_id (prevent duplicates)
       [ ] Computed: sum(shot.dose) for all shots in session
       [ ] NO MANUAL CREATION ENDPOINT — event-driven only

  [ ] 🔴 CalibrationSessionApproved event handler
       [ ] Subscribes to event from File 19
       [ ] Creates CalibrationWasteRecord
       [ ] Deducts roasted bean inventory at branch
       [ ] Posts: Dr Cost of Quality / Cr Inventory
       [ ] Idempotent (UNIQUE constraint prevents duplicate handlers)

  [ ] Equipment Drift Detection
       [ ] Background analysis of calibration patterns
       [ ] Identifies equipment requiring more shots than baseline
       [ ] 7-day alert cooldown to prevent fatigue

  [ ] Reconciliation job
       [ ] Nightly: count CalibrationSessions(APPROVED) vs. CalibrationWasteRecords
       [ ] Alert on discrepancy


┌─────────────────────────────────────────────────────────────────────────────┐
│  2.3  QC TESTING (File 21)                                                  │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 QCTestRecord + QCTestAttribute entities
       [ ] One QCTestRecord per completed RoastingBatch
       [ ] Multiple attributes scored
       [ ] Compliance Rule CR-001: every COMPLETED batch must have QCTestRecord

  [ ] 🔴 QC decision lifecycle
       [ ] PASS | FAIL | CONDITIONAL
       [ ] FAIL → atomic quarantine

  [ ] 🔴 Atomic quarantine on FAIL
       [ ] Single transaction:
            - Batch status → QC_FAILED
            - Lot status → UNDER_INVESTIGATION
            - Inventory marked unavailable for sale
            - QCWasteLog created
            - Cost of Quality posted
            - QCFailed event fired
            - Alert to Quality Manager + Operations Manager

  [ ] 🔴 CONDITIONAL handling
       [ ] usage_restrictions on the batch
       [ ] Sales Module checks restrictions at order creation
       [ ] Cannot ship restricted batch to wrong channel

  [ ] 🔴 QC override workflow
       [ ] Authority Matrix AM-016 (Quality Manager only)
       [ ] Mandatory override reason
       [ ] QCOverrideRecord created (separate entity)
       [ ] Permanently visible in batch history


┌─────────────────────────────────────────────────────────────────────────────┐
│  2.4  EVENTS / OPERATIONAL CALENDAR (File 12)                               │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 EquipmentRegistry (foundational)
       [ ] EquipmentRecord entity (used by Files 19, 23)
       [ ] Status: ACTIVE | UNDER_MAINTENANCE | RETIRED
       [ ] maintenance_interval_days, last_maintenance_at, next_maintenance_due
       [ ] EquipmentStatusChanged event firing

  [ ] 🔴 OperationalEvent entity
       [ ] Event types: MEETING, MAINTENANCE, PRODUCT_LAUNCH, CAMPAIGN,
            SUPPLIER_DELIVERY, TRAINING
       [ ] Status: SCHEDULED → IN_PROGRESS → COMPLETED | CANCELLED | OVERDUE

  [ ] 🔴 DailyTaskSchedule (shared with Files 23, 24)
       [ ] scope discriminator: OPERATIONS | COFFEE_EQUIPMENT | PREMISES
       [ ] frequency, time windows, branch_id

  [ ] 🔴 DailyTaskGeneratorJob (SHARED)
       [ ] Runs every minute during operating hours
       [ ] Generates task instances per active schedule
       [ ] UNIQUE constraint prevents duplicates: (schedule_id, branch_id, generation_date, scheduled_time)
       [ ] Branch operating hours respected (BranchSettings)

  [ ] 🔴 Product Launch readiness checklist
       [ ] System-verified items (NOT manual ticks):
            - "Official Recipe Published" → calls RecipeLibraryService.hasPublishedRecipe()
            - "Minimum Stock Confirmed" → calls InventoryService.getAvailableStock()
       [ ] READY status hard-blocked when required items incomplete

  [ ] Maintenance alert cascade
       [ ] 7 / 3 / 1 day alerts
       [ ] When status → UNDER_MAINTENANCE:
            - Suppress calibration tasks (File 19)
            - Pause cleaning tasks (File 23)

  [ ] Calendar view UI
       [ ] Filter: type, branch, period
       [ ] Mystery Shopper events filtered out for unauthorised roles


┌─────────────────────────────────────────────────────────────────────────────┐
│  2.5  EQUIPMENT CLEANING (File 23) + PREMISES CLEANING (File 24)            │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] EquipmentCleaningTaskInstance + Log
       [ ] Generated by shared DailyTaskGeneratorJob
       [ ] scope = COFFEE_EQUIPMENT
       [ ] Grace windows (default 30 min for morning tasks)

  [ ] PremisesCleaningTaskInstance + Log
       [ ] scope = PREMISES
       [ ] Frequency tiers per area type

  [ ] EquipmentHygieneScore (computed)
       [ ] On-time completion rate
       [ ] Rolling 30 days default

  [ ] PremisesCleanlinessScore (computed)
       [ ] Separate from Equipment Hygiene Score

  [ ] EquipmentStatusChanged consumer (File 23)
       [ ] Auto-pause tasks for UNDER_MAINTENANCE equipment
       [ ] Resume when status returns to ACTIVE

  [ ] Overdue task alerts
       [ ] Past grace window → OVERDUE
       [ ] Alert to assignee + Branch Manager


┌─────────────────────────────────────────────────────────────────────────────┐
│  2.6  FIELD VISITS (File 09) — Phase 1 scope                                │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 FieldVisitRecord entity (unified for 4 types)
       [ ] visit_type discriminator
       [ ] Phase 1: WHOLESALE_CLIENT_VISIT, BRANCH_QUALITY_VISIT
       [ ] Phase 2: MYSTERY_SHOPPER, SURPRISE_INSPECTION

  [ ] Visit workflow
       [ ] CREATE → START (GPS capture) → CALIBRATION (linked session) →
            ISSUES + RECOMMENDATIONS → SUBMIT → REVIEW → APPROVE → SEND_REPORT

  [ ] QualityIssue per identified problem
       [ ] severity: LOW | MEDIUM | HIGH | CRITICAL
       [ ] CRITICAL → immediate alert before review gate

  [ ] VisitEvidencePhoto
       [ ] Photos categorised (BEFORE, AFTER, ISSUE, GENERAL, RECEIPT)
       [ ] Tenant-scoped storage

  [ ] 🔴 Quality Manager review gate [Master Invariant 14]
       [ ] APPROVED status required before report can be sent
       [ ] Server-side hard block on /send-report endpoint
       [ ] Integration test required

  [ ] 🔴 Partner Care Report PDF generation
       [ ] Branded template per tenant
       [ ] Configurable: logo, brand colors, contact details
       [ ] Contains: visit data, current recipe, recommended recipe, calibration,
            issues with photos, recommendations

  [ ] CorrectiveActionTask generation
       [ ] HIGH/CRITICAL issues → automatic tasks on approval
       [ ] Assigned role + due date
       [ ] Overdue alerts
       [ ] Resolution verification

  [ ] Mobile offline support
       [ ] Pre-cache last 3 visits for context
       [ ] Buffer entries locally
       [ ] Sync with idempotency on reconnect



════════════════════════════════════════════════════════════════════════════════
              PHASE 3 — GOVERNANCE & MANAGEMENT VISIBILITY
════════════════════════════════════════════════════════════════════════════════


┌─────────────────────────────────────────────────────────────────────────────┐
│  3.1  GOVERNANCE MODULE FULL (File 08)                                      │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] PartnerRecord + PartnerMeeting + PartnerDecision
       [ ] Ownership percentages sum to 100% (constraint)
       [ ] Meeting workflow with quorum
       [ ] Decision recording from meetings

  [ ] 🔴 StrategicDecision entity
       [ ] Sequential decision_code (DEC-YYYY-NNN)
       [ ] Linked modules + responsible user
       [ ] Status: PENDING → IN_PROGRESS → COMPLETED | DELAYED | CANCELLED
       [ ] Overdue escalation (1-7 days MEDIUM, 8-30 days HIGH, >30 days CRITICAL)

  [ ] 🔴 CompanyPolicy + PolicyAcknowledgment
       [ ] Versioned (new version → previous SUPERSEDED)
       [ ] blocks_module_access flag (gates module UI)
       [ ] Acknowledgment deadline alerts
       [ ] Re-acknowledgment on new version

  [ ] 🔴 ComplianceRule + ComplianceEvaluation
       [ ] PHASE 1: ALERT-ONLY (no blocking)
       [ ] Standard rules:
            CR-001: QC required before packaging
            CR-002: Daily calibration compliance
            CR-003: No order below minimum price
            CR-004: Credit limit compliance
            CR-005: Expense approval compliance
            CR-006: Active employee contract compliance

  [ ] ComplianceMonitoringService
       [ ] Event-driven evaluation (real-time rules)
       [ ] Scheduled evaluation (daily/weekly rules)
       [ ] ComplianceScore computation
       [ ] Alert deduplication

  [ ] Governance Dashboard
       [ ] 6 panels: Compliance Overview, Decision Execution, Risk Summary,
            Policy Compliance, Authority Matrix Health, Conflict of Interest
       [ ] Composite Governance Score

  [ ] Phase 2 additions (deferred):
       [ ] RiskItem entity with 5x5 matrix
       [ ] ConflictOfInterestRecord (column-level access control)
       [ ] StrategyExecutionLink (decisions → OKR)
       [ ] Electronic voting


┌─────────────────────────────────────────────────────────────────────────────┐
│  3.2  REPORTS CENTER (File 15)                                              │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] ReportDefinition + ReportRun entities
       [ ] Per report type
       [ ] Status: GENERATING | COMPLETE | FAILED

  [ ] 🔴 Service-layer queries only
       [ ] No direct database queries across modules
       [ ] All data via module services
       [ ] Counting rules enforced in service layer

  [ ] 🔴 Master Invariant 9 enforcement
       [ ] Integration test: Reports = Dashboard = Analytics for same query
       [ ] Runs in CI; deploy blocked on divergence

  [ ] Standard report catalog (40+ reports)
       [ ] Financial: P&L, Balance Sheet, Cash Flow, AR/AP Aging
       [ ] Operational: Production Yield, Inventory, Waste, Equipment Maintenance
       [ ] Quality: QC Pass Rate, Field Visit Summary, Calibration Compliance
       [ ] Sales: Revenue by Customer/Product/Channel/Rep, Commission
       [ ] Marketing: Campaign ROI, Attribution, Spend
       [ ] HR: Attendance, Performance, Compliance, Payroll
       [ ] Governance: Compliance Scores, Audit Findings, Decision Execution

  [ ] ReportSchedule for automated delivery
       [ ] Daily/weekly/monthly schedules
       [ ] Email delivery
       [ ] Configurable recipients per report

  [ ] ReportArchive (immutable)
       [ ] All generated reports retained
       [ ] Configurable retention period per type


┌─────────────────────────────────────────────────────────────────────────────┐
│  3.3  EXECUTIVE OVERVIEW DASHBOARD (File 07)                                │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] Dashboard panels (1-7 and 9 — skip 8 for Phase 1)
       [ ] P1: Executive Overview (Quick Health)
       [ ] P2: Financial Health
       [ ] P3: Sales Intelligence
       [ ] P4: Operations Control
       [ ] P5: Quality Control
       [ ] P6: Marketing Performance
       [ ] P7: Strategic Alerts (CRITICAL!)
       [ ] P9: Upcoming Strategic Events

  [ ] DashboardAggregationService
       [ ] Calls module services (never direct DB)
       [ ] Each panel fault-isolated (try-catch)
       [ ] Failed panel shows "Data temporarily unavailable"

  [ ] AlertQueue consumer
       [ ] CRITICAL alerts surface immediately
       [ ] Auto-resolve when conditions clear

  [ ] Drill-down to underlying modules
       [ ] Click revenue figure → Reports Center
       [ ] Click QC alert → File 21 detail view

  [ ] Period selector + filters

  [ ] DashboardSettings per tenant


┌─────────────────────────────────────────────────────────────────────────────┐
│  3.4  INTERNAL AUDIT (File 13)                                              │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] AuditRule per audit area
       [ ] Financial (F-01 to F-06)
       [ ] Quality (Q-01 to Q-04)
       [ ] Sales (S-01 to S-05)
       [ ] HR (H-01 to H-05)
       [ ] Operational (O-01 to O-08)

  [ ] AuditFinding lifecycle
       [ ] OPEN → UNDER_INVESTIGATION → RESOLVED | DISMISSED | ESCALATED
       [ ] CRITICAL findings → CEO escalation

  [ ] AuditCycle entity (monthly/quarterly/annual)

  [ ] AuditActivityLog (auditor's working log)
       [ ] APPEND-ONLY at database level

  [ ] 🔴 INTERNAL_AUDITOR role has NO WRITE PERMISSIONS
       [ ] Code review enforced
       [ ] Permission set lacks .create/.update on operational modules
       [ ] Separation of duties



════════════════════════════════════════════════════════════════════════════════
              PHASE 4 — COMMERCIAL & STRATEGIC EXTENSIONS
════════════════════════════════════════════════════════════════════════════════


┌─────────────────────────────────────────────────────────────────────────────┐
│  4.1  MARKETING MODULE (File 14)                                            │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] MarketingCampaign with status lifecycle
       [ ] PLANNED → ACTIVE → COMPLETED

  [ ] 🔴 Attribution method mandatory before activation
       [ ] Activation API hard-rejects without attribution_method
       [ ] Methods: LAST_TOUCH, FIRST_TOUCH, LINEAR, COUPON_CODE, UTM_TAG

  [ ] CampaignAttribution + CampaignSpend
       [ ] Actual spend from POSTED expense entries linked to campaign
       [ ] ROI = (attributed_revenue - actual_spend) / actual_spend × 100

  [ ] MarketingContent + MediaAsset
       [ ] Tenant-scoped storage
       [ ] NO auto-publish (manual approval per post)

  [ ] CustomerSegment for targeting

  [ ] Campaign ROI dashboard
       [ ] Per campaign
       [ ] By channel
       [ ] Period comparison


┌─────────────────────────────────────────────────────────────────────────────┐
│  4.2  ANALYTICS TOOLS (File 11)                                             │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] AnalyticsQueryService
       [ ] Central dispatcher
       [ ] Calls module services (no direct DB)
       [ ] Per-query caching with TTL

  [ ] 🔴 Forecasting outputs labeled
       [ ] method, confidence, data_points_used
       [ ] "Forecast" prefix in UI
       [ ] LOW confidence warning when < 8 weeks of data

  [ ] AnalyticsAlertRule
       [ ] Configurable per tenant
       [ ] Cooldown (default 7 days)

  [ ] HR analytics (permission-gated)
       [ ] Double permission check
       [ ] Anonymised aggregates

  [ ] Phase 2 additions (deferred):
       [ ] Financial Modelling (3 scenarios)
       [ ] Seasonal Analysis
       [ ] Marketing ROI Analytics


┌─────────────────────────────────────────────────────────────────────────────┐
│  4.3  STRATEGIC PERFORMANCE CENTER / OKR (File 18)                          │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] Objective + KeyResult entities
       [ ] Hierarchy: Company → Department → Team (Phase 2: Individual)

  [ ] 🔴 KRDataSource for AUTO_SYNC
       [ ] 18 standard data source query references
       [ ] References operational module services (not direct DB)
       [ ] Same counting rules as Reports

  [ ] KRSyncJob
       [ ] Daily/weekly per KR configuration
       [ ] Updates actual_value from data source

  [ ] 🔴 WeeklyCheckIn mandatory
       [ ] Per KR owner
       [ ] Missed check-in alerts to manager
       [ ] Pace computed: actual / expected at current point in period

  [ ] Recovery Mode at < 50% pace
       [ ] RecoveryPlan required within 7 days
       [ ] Reviewed weekly
       [ ] Linked to StrategyExecutionLink (Phase 2)

  [ ] Strategic Performance Dashboard


┌─────────────────────────────────────────────────────────────────────────────┐
│  4.4  FIELD VISITS PHASE 2 (File 09)                                        │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 MYSTERY_SHOPPER visit type
       [ ] Row-level security at database level
       [ ] Visible only to Quality Manager + CEO
       [ ] Generic corrective tasks for branch staff
       [ ] All access logged with enhanced detail

  [ ] SURPRISE_INSPECTION visit type
       [ ] Multi-area checklist
       [ ] Findings + corrective actions

  [ ] 🔴 RecipeIntelligenceSummary (nightly)
       [ ] Aggregates calibration data from Files 09 + 19
       [ ] IQR outlier exclusion
       [ ] Per (tenant, bean, lot, brew_method)
       [ ] Confidence labels (LOW < 10, MEDIUM 10-30, HIGH > 30 sessions)

  [ ] Field Intelligence Dashboard
       [ ] Branch performance rankings
       [ ] Wholesale customer view
       [ ] Calibration quality per bean
       [ ] Issue frequency analysis
       [ ] Corrective action tracking



════════════════════════════════════════════════════════════════════════════════
              PHASE 5 — AI & EXTERNAL INTEGRATIONS
════════════════════════════════════════════════════════════════════════════════


┌─────────────────────────────────────────────────────────────────────────────┐
│  5.1  AI AGENT — ADVISORY ONLY (File A — Phase 1)                           │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] AgentSession entity
       [ ] User-bound (AI acts on behalf of user)
       [ ] Conversation history

  [ ] AgentTool catalog (read-only tools only Phase 1)
       [ ] Per tool: required_permission, rate_limit
       [ ] tool_id, description, parameter schema

  [ ] 🔴 AgentAuditLog (PRE-EXECUTION, BLOCKING)
       [ ] Synchronous write before tool execution
       [ ] If log fails, tool blocked
       [ ] Full forensic capability

  [ ] 🔴 AgentToolGateway (only entry point)
       [ ] Permission check using calling user's permissions
       [ ] No DB or service direct access
       [ ] Tenant_id from session only

  [ ] Executive Dashboard Panel 8 (CEO Decision Panel)
       [ ] AI-generated suggestions
       [ ] No actions taken (advisory only Phase 1)


┌─────────────────────────────────────────────────────────────────────────────┐
│  5.2  AI READ-ONLY TOOLS (File A — Phase 2)                                 │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] Management Agent tool catalog
       [ ] getRevenueByPeriod, getTopCustomers, getProductPerformance
       [ ] getComplianceScore, getOverdueApprovals
       [ ] Each tool has rate limit and permission requirement


┌─────────────────────────────────────────────────────────────────────────────┐
│  5.3  EXTERNAL INTEGRATIONS                                                 │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] FoodicsAdapter (Phase 2)
       [ ] Adapter interface per File B §4.5
       [ ] Price sync (Pricing → Foodics)
       [ ] Sales sync (Foodics → ERP)
       [ ] Tenant-scoped credentials

  [ ] QoyodAdapter (Phase 2)
       [ ] One-way push: ERP POSTED entries → Qoyod
       [ ] QoyodSyncRecord tracking
       [ ] Periodic reconciliation report

  [ ] ZATCA Phase 2 e-invoicing
       [ ] Live API integration
       [ ] Compliance with current ZATCA regulations
       [ ] All invoices submitted post-posting

  [ ] Social Media APIs (Phase 2)
       [ ] Meta, Twitter, TikTok
       [ ] Manual approval per post (no auto-publish)



════════════════════════════════════════════════════════════════════════════════
              CROSS-CUTTING IMPLEMENTATION TASKS
════════════════════════════════════════════════════════════════════════════════


┌─────────────────────────────────────────────────────────────────────────────┐
│  TESTING REQUIREMENTS                                                       │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Unit tests required for:
       [ ] Sample roast produces zero inventory movements
       [ ] Negative net salary blocks payroll
       [ ] PriceResolutionService hierarchy (Level 1 → 4)
       [ ] ExtractionDiagnosticEngine with known scenarios
       [ ] SCA cupping score computation
       [ ] CommissionRecord splits sum to 100%
       [ ] DiscountRule cannot exceed max_discount_pct_cap

  [ ] 🔴 Integration tests required for:
       [ ] Reports Center = Executive Dashboard = Analytics for same query
       [ ] OrderShipped event → COGS entry posted
       [ ] CalibrationSessionApproved event → CalibrationWasteRecord created
       [ ] QC FAIL → atomic quarantine (all 4 effects in single transaction)
       [ ] Order cancellation → inventory reservation released
       [ ] Authority Matrix self-approval blocked
       [ ] Authority Matrix dual approval required
       [ ] Sample roast → ZERO inventory ledger entries
       [ ] Mystery Shopper records inaccessible to unauthorised roles
       [ ] Partner Care Report send fails without APPROVED status

  [ ] 🔴 Database-level tests:
       [ ] AuditLog UPDATE/DELETE attempts fail
       [ ] PostedJournalEntry UPDATE/DELETE attempts fail
       [ ] PriceChangeLog UPDATE/DELETE attempts fail
       [ ] PublishedRecipeValues UPDATE/DELETE attempts fail
       [ ] CommissionRecord UPDATE attempts fail
       [ ] Row-level security: cross-tenant query returns no results

  [ ] 🔴 Performance tests:
       [ ] PriceResolutionService < 50ms (P95)
       [ ] AuthorityMatrixService.resolveApprover() < 20ms (P95)
       [ ] RecipeLibraryService.getOfficialRecipe() < 100ms (P95)
       [ ] Executive Dashboard load < 3s
       [ ] Standard report generation < 30s


┌─────────────────────────────────────────────────────────────────────────────┐
│  SECURITY REQUIREMENTS                                                      │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Penetration test before each phase release
       [ ] Cross-tenant data access attempts
       [ ] Permission escalation attempts
       [ ] SQL injection
       [ ] CSRF, XSS
       [ ] Session hijacking

  [ ] 🔴 Sensitive data handling
       [ ] Mystery Shopper records: row-level + column-level security
       [ ] Conflict of Interest: column-level encryption
       [ ] Payroll: column-level access control
       [ ] Customer payment details: encrypted at rest

  [ ] 🔴 Audit log integrity
       [ ] INSERT-only enforcement tested
       [ ] No backdoor admin endpoints for log modification

  [ ] Rate limiting per tenant
       [ ] API rate limits
       [ ] Per-endpoint limits
       [ ] Per-user limits


┌─────────────────────────────────────────────────────────────────────────────┐
│  ONBOARDING & SAAS OPERATIONS                                               │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] 🔴 Tenant onboarding wizard
       [ ] Tenant + Branch setup
       [ ] User invitations
       [ ] Authority Matrix configuration (standard template)
       [ ] Policy publication
       [ ] Chart of accounts (template)
       [ ] Product catalog import
       [ ] Customer/supplier import

  [ ] Subscription management
       [ ] Plan tiers (Standard, Advanced, Enterprise)
       [ ] Feature flags per tier
       [ ] Billing integration (later)

  [ ] Tenant offboarding
       [ ] Data export
       [ ] Soft archive (not hard delete)
       [ ] Compliance retention


┌─────────────────────────────────────────────────────────────────────────────┐
│  DOCUMENTATION & TRAINING                                                   │
└─────────────────────────────────────────────────────────────────────────────┘

  [ ] API documentation (auto-generated from OpenAPI)
  [ ] Module developer guides (one per module)
  [ ] Tenant admin guide
  [ ] End-user guides per role
  [ ] Onboarding video tutorials
  [ ] Troubleshooting runbooks
  [ ] Incident response procedures



════════════════════════════════════════════════════════════════════════════════
              PRE-LAUNCH CHECKLIST (BEFORE PHASE 1 GO-LIVE)
════════════════════════════════════════════════════════════════════════════════

All items below MUST be checked before any tenant goes live with Phase 1:

  [ ] 🔴 Module Boundary Linter active in CI
  [ ] 🔴 AuthorityMatrixService deployed and tested (< 20ms)
  [ ] 🔴 PriceResolutionService deployed and tested (< 50ms)
  [ ] 🔴 RecipeLibraryService deployed and tested (< 100ms)
  [ ] 🔴 All 20 Critical Risks (CR-01 to CR-20) mitigated and tested
  [ ] 🔴 Master Invariant 9 integration test passing
  [ ] 🔴 Master Invariant 4 unit test passing (sample ≠ inventory)
  [ ] 🔴 Master Invariant 5 integration test passing (COGS at shipment)
  [ ] 🔴 Master Invariant 7 query test passing (POSTED-only)
  [ ] 🔴 Penetration test completed (cross-tenant isolation)
  [ ] 🔴 Authority Matrix standard template available
  [ ] 🔴 Onboarding wizard complete
  [ ] 🔴 Tenant data export capability working
  [ ] 🔴 Backup and restore tested
  [ ] 🔴 Incident response procedures documented
  [ ] 🔴 Monitoring and alerting configured
  [ ] 🟡 Standard Chart of Accounts template available
  [ ] 🟡 Standard product catalog templates available
  [ ] 🟡 User documentation complete for all Phase 1 modules
  [ ] 🟡 Training materials prepared
  [ ] 🟡 Support runbook complete



════════════════════════════════════════════════════════════════════════════════
              QUICK-REFERENCE PROGRESS SUMMARY
════════════════════════════════════════════════════════════════════════════════

Track overall progress per phase by counting completed [x] markers:

  PHASE 0 (FOUNDATIONS):           [ ] / [estimated 65 tasks]
  PHASE 1 (CORE OPERATIONS):       [ ] / [estimated 150 tasks]
  PHASE 2 (QUALITY OPS):           [ ] / [estimated 80 tasks]
  PHASE 3 (GOVERNANCE):            [ ] / [estimated 45 tasks]
  PHASE 4 (COMMERCIAL):            [ ] / [estimated 50 tasks]
  PHASE 5 (AI & INTEGRATIONS):     [ ] / [estimated 30 tasks]
  
  CROSS-CUTTING:                   [ ] / [estimated 40 tasks]
  PRE-LAUNCH GATE:                 [ ] / [estimated 20 tasks]

  TOTAL: 480+ tasks for full ERP implementation



════════════════════════════════════════════════════════════════════════════════
              END OF IMPLEMENTATION CHECKLIST
                                                                                
        This document is companion to:                                          
        - HIQBAH_ERP_MASTER_DOCUMENT.txt (architectural reference)              
        - HIQBAH_ERP_MERMAID_DIAGRAMS.md (visual reference)                     
        - 26 individual module documents (full detail)                          
                                                                                
        For full detail on any task, refer to the relevant module document.    
                                                                                
════════════════════════════════════════════════════════════════════════════════

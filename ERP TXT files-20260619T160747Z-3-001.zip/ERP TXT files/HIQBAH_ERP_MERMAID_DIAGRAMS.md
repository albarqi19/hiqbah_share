════════════════════════════════════════════════════════════════════════════════
                                                                                
              HIQBAH ERP — MERMAID PROCESS DIAGRAMS                             
                                                                                
              مخططات التدفق الشاملة للنظام                                       
                                                                                
════════════════════════════════════════════════════════════════════════════════

This document contains comprehensive Mermaid flowchart diagrams covering:
  - System architecture (high-level)
  - End-to-end workflow (Arabic + English)
  - Coffee lifecycle (sample → shipment)
  - Daily operations flow
  - Approval workflow via Authority Matrix
  - Event-driven inter-module communication
  - SaaS / multi-tenant request flow

How to view: paste any diagram block into https://mermaid.live/
              or use any Mermaid-compatible viewer (VS Code, GitHub, Notion).



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 1 — HIGH-LEVEL SYSTEM ARCHITECTURE
════════════════════════════════════════════════════════════════════════════════

```mermaid
graph TB
    subgraph CLIENTS["Client Surfaces"]
        WEB["Web Admin<br/>(Management)"]
        IOS["iOS App<br/>(Field/Branch)"]
        ANDROID["Android App<br/>(Field/Branch)"]
        STATION["Station Screens<br/>(Branch Counter)"]
        API_CLIENT["External API<br/>(Integrations)"]
    end

    subgraph GATEWAY["API Gateway Layer"]
        AUTH_CHECK["Session Validation<br/>+ Tenant Resolution<br/>(File 01)"]
        RBAC["RBAC Permission<br/>Check"]
        RATE["Rate Limiting"]
    end

    subgraph INFRA["File B — Shared Infrastructure"]
        APPROVAL["ApprovalWorkflow<br/>Service"]
        EVENTBUS["EventBus<br/>(Outbox Pattern)"]
        NOTIF["Notification<br/>Service"]
        AUDIT["AuditLog Service<br/>(INSERT-only)"]
        FEATURE["Feature Flag<br/>Service"]
    end

    subgraph CORE["Core Operational Modules"]
        F02["File 02<br/>Accounting"]
        F03["Files 03+04+05<br/>Coffee Lifecycle"]
        F06["File 06<br/>Order Workflow"]
        F10["File 10<br/>Pricing"]
        F16["File 16<br/>Sales"]
        F17["File 17<br/>HR"]
        F25["File 25<br/>Recipe Library"]
    end

    subgraph QUALITY["Quality & Operations"]
        F19["File 19<br/>Calibration"]
        F21["File 21<br/>QC Testing"]
        F22["File 22<br/>Cal. Waste"]
        F09["File 09<br/>Field Visits"]
        F12["File 12<br/>Events/Calendar"]
        F20["File 20<br/>Inventory Count"]
        F23["File 23<br/>Equip. Cleaning"]
        F24["File 24<br/>Premises Cleaning"]
    end

    subgraph GOVERNANCE["Governance & Visibility"]
        F08["File 08<br/>Governance<br/>(Authority Matrix)"]
        F13["File 13<br/>Internal Audit"]
        F07["File 07<br/>Exec Dashboard"]
        F11["File 11<br/>Analytics"]
        F15["File 15<br/>Reports Center"]
        F14["File 14<br/>Marketing"]
        F18["File 18<br/>OKR"]
    end

    subgraph EXTERNAL["External Integrations (Phase 2+)"]
        FOODICS["Foodics POS"]
        QOYOD["Qoyod Accounting"]
        ZATCA["ZATCA E-Invoice"]
        SOCIAL["Social Media APIs"]
        AI["AI Agent<br/>(File A)"]
    end

    subgraph DB["Data Layer"]
        DBMAIN[("Main Database<br/>Tenant-Scoped<br/>Row-Level Security")]
        STORAGE[("Tenant-Scoped<br/>File Storage")]
        AUDITDB[("Audit Log<br/>INSERT-only")]
    end

    CLIENTS --> GATEWAY
    GATEWAY --> AUTH_CHECK
    AUTH_CHECK --> RBAC
    RBAC --> RATE
    RATE --> INFRA
    RATE --> CORE
    RATE --> QUALITY
    RATE --> GOVERNANCE

    CORE -.uses.-> INFRA
    QUALITY -.uses.-> INFRA
    GOVERNANCE -.uses.-> INFRA

    F08 -.Authority Matrix lookup.-> APPROVAL
    CORE -.fires events.-> EVENTBUS
    QUALITY -.fires events.-> EVENTBUS
    EVENTBUS -.delivers.-> CORE
    EVENTBUS -.delivers.-> QUALITY
    EVENTBUS -.delivers.-> GOVERNANCE

    CORE --> DBMAIN
    QUALITY --> DBMAIN
    GOVERNANCE --> DBMAIN
    INFRA --> DBMAIN
    AUDIT --> AUDITDB
    
    F14 -.optional sync.-> SOCIAL
    F02 -.optional sync.-> QOYOD
    F02 -.optional sync.-> ZATCA
    CORE -.optional sync.-> FOODICS
    AI -.via gateway.-> INFRA
    
    style F08 fill:#ff9999
    style APPROVAL fill:#ffcc99
    style EVENTBUS fill:#ffcc99
    style AUDIT fill:#ffcc99
    style DBMAIN fill:#ccccff
    style AUDITDB fill:#ffaaaa
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 2 — END-TO-END WORKFLOW (ENGLISH)
════════════════════════════════════════════════════════════════════════════════

```mermaid
flowchart TD
    Start(["Tenant Subscribes<br/>SaaS Onboarding"]) --> TENANT_SETUP["Tenant + Branch<br/>+ User Setup<br/>(File 01)"]
    
    TENANT_SETUP --> AM_CONFIG["Authority Matrix<br/>Configuration<br/>(File 08)"]
    AM_CONFIG --> POLICIES["Company Policies<br/>+ Acknowledgments<br/>(File 08)"]
    
    POLICIES --> SUB_CHECK{"Subscription<br/>Active?"}
    SUB_CHECK -->|No| BLOCK["Block Access<br/>+ Notify Tenant Admin"]
    SUB_CHECK -->|Yes| OPS_BEGIN
    
    OPS_BEGIN["==Operations Begin=="] --> SUPPLIER_PHASE
    
    subgraph COFFEE_PHASE["Coffee Lifecycle Phase"]
        SUPPLIER_PHASE["Supplier Offers<br/>Coffee Sample"]
        SUPPLIER_PHASE --> SAMPLE["Sample Arrival<br/>(Files 03/04/05)"]
        SAMPLE --> SAMPLE_ROAST["Sample Roast<br/>sample_roast=true<br/>NO INVENTORY IMPACT"]
        SAMPLE_ROAST --> CUPPING["SCA Cupping<br/>Session"]
        CUPPING --> CUP_DECISION{"Cupping<br/>Decision?"}
        CUP_DECISION -->|REJECT| REJECT_END(["Reject Lot"])
        CUP_DECISION -->|HOLD| SAMPLE
        CUP_DECISION -->|APPROVE| PO_CREATE["Create Purchase Order<br/>(Gated by Approved Cupping)"]
        PO_CREATE --> PO_APPROVAL{"Authority Matrix<br/>Approval?<br/>(AM-009/010)"}
        PO_APPROVAL -->|Rejected| REJECT_END
        PO_APPROVAL -->|Approved| RECEIVE["Goods Receipt<br/>+ Arrival Sample Match"]
        RECEIVE --> LOT_CREATE["Generate lot_sn<br/>(TRACEABILITY ANCHOR)"]
        LOT_CREATE --> GREEN_INV["Green Coffee Inventory<br/>(Dr Inventory / Cr AP)"]
    end
    
    GREEN_INV --> ORDER_PHASE
    
    subgraph ORDER_PHASE["Order Phase"]
        SALES_REQUEST["Sales Rep Receives<br/>Customer Order<br/>(File 16)"]
        SALES_REQUEST --> PRICE_RESOLVE["PriceResolutionService<br/>(File 10)<br/>Resolves Price"]
        PRICE_RESOLVE --> DISCOUNT_CHECK{"Discount<br/>Required?"}
        DISCOUNT_CHECK -->|Yes| DISC_AUTH{"Authority Matrix<br/>Discount Approval?<br/>(AM-001/002/003)"}
        DISC_AUTH -->|Rejected| REJECT_ORDER(["Reject Order"])
        DISC_AUTH -->|Approved| ORDER_CREATE
        DISCOUNT_CHECK -->|No| ORDER_CREATE
        ORDER_CREATE["Create Sales Order<br/>(File 06)<br/>Status: DRAFT"]
        ORDER_CREATE --> INV_RESERVE["Inventory Reservation"]
        INV_RESERVE --> PAYMENT_CHECK{"Customer<br/>Credit OK?"}
        PAYMENT_CHECK -->|No| HOLD["Hold Order<br/>Await Payment"]
        HOLD --> PAYMENT_CONF["Payment Confirmed<br/>(File 02)"]
        PAYMENT_CHECK -->|Yes| PAYMENT_CONF
        PAYMENT_CONF --> ORDER_CONF["Order CONFIRMED<br/>Commission Snapshot<br/>(File 06 §4.4)"]
    end
    
    ORDER_CONF --> PRODUCTION_PHASE
    
    subgraph PRODUCTION_PHASE["Production Phase"]
        PROD_SCHEDULE["Schedule Production"]
        PROD_SCHEDULE --> ROAST["Roasting Batch<br/>sample_roast=false<br/>(File 06)"]
        ROAST --> ROAST_DEDUCT["Deduct Green Coffee<br/>Inventory"]
        ROAST_DEDUCT --> QC_TEST["QC Testing<br/>(File 21)"]
        QC_TEST --> QC_DECISION{"QC<br/>Decision?"}
        QC_DECISION -->|FAIL| QUARANTINE["Atomic Quarantine<br/>(Lot UNDER_INVESTIGATION)"]
        QUARANTINE --> QC_OVERRIDE{"Quality Manager<br/>Override?<br/>(AM-016)"}
        QC_OVERRIDE -->|Yes| PACKAGE
        QC_OVERRIDE -->|No| DISPOSAL(["Disposal"])
        QC_DECISION -->|CONDITIONAL| PACKAGE_RESTRICTED["Package with<br/>Usage Restrictions"]
        QC_DECISION -->|PASS| PACKAGE
        PACKAGE["Packaging Batch"]
        PACKAGE_RESTRICTED --> PACKAGE
        PACKAGE --> FG_INV["Finished Goods<br/>Inventory"]
    end
    
    FG_INV --> FULFILLMENT_PHASE
    
    subgraph FULFILLMENT_PHASE["Fulfillment & Finance Phase"]
        SHIP["Shipment<br/>(File 06)"]
        SHIP --> SHIP_EVENT["Fire OrderShipped<br/>Event"]
        SHIP_EVENT --> COGS["Accounting Module<br/>Posts COGS<br/>(Dr COGS / Cr Inventory)<br/>(Master Invariant 5)"]
        COGS --> INVOICE["Generate Invoice<br/>(File 02)"]
        INVOICE --> INV_APPROVAL{"Invoice > 50k SAR?<br/>(AM-005/006)"}
        INV_APPROVAL -->|Yes - dual approval| INV_POST
        INV_APPROVAL -->|No - Finance Mgr| INV_POST
        INV_POST["Invoice POSTED<br/>(Master Invariant 7)"]
        INV_POST --> ZATCA_SYNC{"ZATCA Enabled?"}
        ZATCA_SYNC -->|Phase 2| ZATCA_API["ZATCA E-Invoice API"]
        ZATCA_SYNC -->|No| QOYOD_SYNC
        ZATCA_API --> QOYOD_SYNC
        QOYOD_SYNC{"Qoyod Enabled?"}
        QOYOD_SYNC -->|Phase 2| QOYOD_PUSH["Push to Qoyod"]
        QOYOD_SYNC -->|No| DELIVERY
        QOYOD_PUSH --> DELIVERY
        DELIVERY["Delivery to Customer"]
        DELIVERY --> PAYMENT_RECEIPT["Payment Received<br/>+ Posted (File 02)"]
    end
    
    PAYMENT_RECEIPT --> POST_PHASE
    
    subgraph POST_PHASE["Post-Sale & Visibility"]
        QUALITY_VISIT["Quality Visit<br/>(File 09)"]
        QUALITY_VISIT --> CALIB["Calibration on<br/>Customer Machine"]
        CALIB --> ISSUES["Log Issues<br/>+ Corrective Actions"]
        ISSUES --> QM_REVIEW{"Quality Manager<br/>Review?"}
        QM_REVIEW -->|Approved| REPORT_SEND["Partner Care Report<br/>Sent to Customer<br/>(MASTER INVARIANT 14)"]
        REPORT_SEND --> RECIPE_INTEL["Recipe Intelligence<br/>Aggregation (Nightly)"]
    end
    
    POST_PHASE --> VISIBILITY
    
    subgraph VISIBILITY["Cross-Cutting Visibility"]
        AUDIT_LOG["AuditLog: Every Action"]
        REPORTS["Reports Center<br/>(File 15)<br/>POSTED data only"]
        DASHBOARD["Executive Dashboard<br/>(File 07)"]
        ANALYTICS["Analytics Tools<br/>(File 11)"]
        OKR["OKR Auto-Sync<br/>(File 18)"]
        COMPLIANCE["Compliance Monitor<br/>(File 08)"]
        INTERNAL_AUDIT["Internal Audit<br/>(File 13)"]
    end
    
    VISIBILITY --> END_NODE(["Continuous<br/>Operations"])
    
    style AM_CONFIG fill:#ff9999
    style PRICE_RESOLVE fill:#99ccff
    style LOT_CREATE fill:#ffcc99
    style QC_TEST fill:#ffaa99
    style COGS fill:#99ff99
    style REPORT_SEND fill:#ffaa99
    style AUDIT_LOG fill:#ccccff
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 3 — END-TO-END WORKFLOW (ARABIC / عربي)
════════════════════════════════════════════════════════════════════════════════

```mermaid
flowchart TD
    Start(["اشتراك العميل<br/>إعداد SaaS"]) --> SETUP["إعداد الشركة + الفروع<br/>+ المستخدمين<br/>(ملف 01)"]
    
    SETUP --> AM["إعداد مصفوفة<br/>الصلاحيات<br/>(ملف 08)"]
    AM --> POL["السياسات + الإقرارات<br/>(ملف 08)"]
    
    POL --> SUB{"الاشتراك<br/>نشط؟"}
    SUB -->|لا| BLK["إيقاف الوصول<br/>+ إبلاغ المدير"]
    SUB -->|نعم| OPS
    
    OPS["==بدء العمليات=="] --> SUPP
    
    subgraph COFFEE["مرحلة دورة حياة البن"]
        SUPP["عرض المورّد لعينة"]
        SUPP --> SAMP["وصول العينة<br/>(ملفات 03+04+05)"]
        SAMP --> ROAST_S["تحميص العينة<br/>sample_roast=true<br/>بدون أثر على المخزون"]
        ROAST_S --> CUP["جلسة التحكيم<br/>(SCA Cupping)"]
        CUP --> CUP_D{"قرار<br/>التحكيم؟"}
        CUP_D -->|رفض| REJ(["رفض اللوت"])
        CUP_D -->|تأجيل| SAMP
        CUP_D -->|موافقة| PO["إنشاء أمر شراء<br/>(مشروط بموافقة التحكيم)"]
        PO --> PO_AUTH{"موافقة مصفوفة<br/>الصلاحيات؟<br/>(AM-009/010)"}
        PO_AUTH -->|رفض| REJ
        PO_AUTH -->|موافقة| REC["استلام البضاعة<br/>+ مطابقة عينة الوصول"]
        REC --> LOT["إنشاء رقم اللوت (lot_sn)<br/>مرساة التتبّع"]
        LOT --> INV_G["مخزون البن الأخضر<br/>(دائن: حسابات الموردين)"]
    end
    
    INV_G --> ORD
    
    subgraph ORDER["مرحلة الطلب"]
        ORD["مندوب المبيعات<br/>يستلم الطلب<br/>(ملف 16)"]
        ORD --> PRICE["خدمة التسعير<br/>(ملف 10)"]
        PRICE --> DISC{"يحتاج<br/>خصم؟"}
        DISC -->|نعم| DISC_A{"موافقة الخصم؟<br/>(AM-001/002/003)"}
        DISC_A -->|رفض| REJ_O(["رفض الطلب"])
        DISC_A -->|موافقة| CRE
        DISC -->|لا| CRE
        CRE["إنشاء أمر البيع<br/>(ملف 06)<br/>الحالة: مسودة"]
        CRE --> RES["حجز المخزون"]
        RES --> PAY{"حد الائتمان<br/>سليم؟"}
        PAY -->|لا| HOLD["تعليق الطلب<br/>انتظار الدفع"]
        HOLD --> PAY_C["تأكيد الدفع<br/>(ملف 02)"]
        PAY -->|نعم| PAY_C
        PAY_C --> CONF["تأكيد الطلب<br/>لقطة عمولة"]
    end
    
    CONF --> PROD
    
    subgraph PRODUCTION["مرحلة الإنتاج"]
        PROD["جدولة الإنتاج"]
        PROD --> ROAST["دفعة تحميص<br/>sample_roast=false"]
        ROAST --> DED["خصم البن الأخضر<br/>من المخزون"]
        DED --> QC["اختبار الجودة<br/>(ملف 21)"]
        QC --> QC_D{"قرار<br/>الجودة؟"}
        QC_D -->|فشل| QR["حجر صحي ذرّي<br/>(لوت تحت التحقيق)"]
        QR --> OVR{"تجاوز مدير الجودة؟<br/>(AM-016)"}
        OVR -->|نعم| PKG
        OVR -->|لا| DISP(["إتلاف"])
        QC_D -->|مشروط| PKG_R["تعبئة بقيود استخدام"]
        QC_D -->|ناجح| PKG
        PKG["دفعة التعبئة"]
        PKG_R --> PKG
        PKG --> FG["مخزون المنتج النهائي"]
    end
    
    FG --> FUL
    
    subgraph FULFILL["مرحلة التسليم والمالية"]
        FUL["الشحن<br/>(ملف 06)"]
        FUL --> EVT["إطلاق حدث الشحن<br/>OrderShipped"]
        EVT --> COGS["محاسبة:<br/>تسجيل تكلفة البضاعة<br/>(مدين تكلفة / دائن مخزون)<br/>(المبدأ 5)"]
        COGS --> INV["إنشاء الفاتورة<br/>(ملف 02)"]
        INV --> APP{"فاتورة > 50ك ر.س؟<br/>(AM-005/006)"}
        APP -->|نعم - موافقة مزدوجة| POST
        APP -->|لا - مدير مالي| POST
        POST["ترحيل الفاتورة<br/>(المبدأ 7)"]
        POST --> ZATCA{"ZATCA مفعّل؟"}
        ZATCA -->|المرحلة 2| Z_API["ZATCA API"]
        ZATCA -->|لا| QY
        Z_API --> QY
        QY{"قيود مفعّل؟"}
        QY -->|المرحلة 2| QY_P["دفع لقيود"]
        QY -->|لا| DEL
        QY_P --> DEL
        DEL["تسليم للعميل"]
        DEL --> RCV["استلام الدفع<br/>+ الترحيل"]
    end
    
    RCV --> POST_S
    
    subgraph POSTSALE["ما بعد البيع والمتابعة"]
        VIS["زيارة جودة<br/>(ملف 09)"]
        VIS --> CAL["معايرة جهاز<br/>العميل"]
        CAL --> ISS["تسجيل المشاكل<br/>+ خطط التصحيح"]
        ISS --> QMR{"مراجعة<br/>مدير الجودة؟"}
        QMR -->|موافقة| RPT["إرسال تقرير العناية<br/>للعميل<br/>(المبدأ 14)"]
        RPT --> RI["تجميع ذكاء الوصفات<br/>(ليلي)"]
    end
    
    POST_S --> VIEW
    
    subgraph VISIB["الشفافية الشاملة"]
        AL["سجل التدقيق:<br/>كل إجراء"]
        REP["مركز التقارير<br/>(ملف 15)<br/>بيانات مرحّلة فقط"]
        DASH["لوحة التحكم<br/>التنفيذية<br/>(ملف 07)"]
        AN["الأدوات التحليلية<br/>(ملف 11)"]
        OKR["أهداف OKR<br/>مزامنة تلقائية<br/>(ملف 18)"]
        COM["مراقبة الالتزام<br/>(ملف 08)"]
        IA["التدقيق الداخلي<br/>(ملف 13)"]
    end
    
    VIEW --> ENDN(["العمليات<br/>المستمرة"])
    
    style AM fill:#ff9999
    style PRICE fill:#99ccff
    style LOT fill:#ffcc99
    style QC fill:#ffaa99
    style COGS fill:#99ff99
    style RPT fill:#ffaa99
    style AL fill:#ccccff
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 4 — AUTHORITY MATRIX APPROVAL FLOW
════════════════════════════════════════════════════════════════════════════════

```mermaid
sequenceDiagram
    autonumber
    participant User as User<br/>(any role)
    participant Module as Operating Module<br/>(any)
    participant AWS as ApprovalWorkflow<br/>Service (File B)
    participant AMS as AuthorityMatrix<br/>Service (File 08)
    participant Cache as In-Memory Cache<br/>(5min TTL)
    participant DB as Database
    participant Notif as Notification<br/>Service
    participant Approver as Approver<br/>(per role)
    participant Audit as AuditLog<br/>Service

    User->>Module: Initiates action<br/>(e.g., 12% discount)
    Module->>AWS: createRequest(tenant_id,<br/>action_type, value, user_id)
    AWS->>AMS: resolveApprover(tenant_id,<br/>action_type, value)
    
    AMS->>Cache: Check cache
    alt Cache hit
        Cache-->>AMS: Return rule
    else Cache miss
        AMS->>DB: Query AuthorityMatrixRule
        DB-->>AMS: Return matching rule
        AMS->>Cache: Store rule (5min TTL)
    end
    
    AMS-->>AWS: {required_approver_role,<br/>requires_dual_approval,<br/>self_approval_allowed}
    
    alt Requester is approver AND self_approval=false
        AWS-->>Module: REJECT - Self-approval blocked
        Module-->>User: "Cannot approve own request"
    else Valid approver routing
        AWS->>DB: Create ApprovalRequest
        AWS->>Audit: Log creation
        AWS->>Notif: sendPush(approver_role)
        Notif-->>Approver: Push notification
        
        Approver->>AWS: approve() or reject()
        
        alt Dual approval required
            AWS->>Notif: sendPush(secondary_role)
            Notif-->>Approver: Second approver notified
            Approver->>AWS: Second approval
        end
        
        AWS->>DB: Update ApprovalRequest
        AWS->>Audit: Log decision
        AWS->>Module: ApprovalCompleted event
        Module->>User: Original action executes<br/>(or rejection notified)
    end
    
    Note over AWS,AMS: Hot path: must complete < 50ms<br/>AMS lookup < 20ms via cache
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 5 — COFFEE LIFECYCLE WITH lot_sn TRACEABILITY
════════════════════════════════════════════════════════════════════════════════

```mermaid
graph LR
    subgraph SAMPLE_PHASE["1. Sample Phase (Pre-Purchase)"]
        S1["Supplier Sample<br/>Arrives"]
        S2["SampleArrival<br/>Record"]
        S3["Sample Roast<br/>sample_roast=true"]
        S4["Cupping Session<br/>(SCA Score)"]
        S5{"Decision"}
        
        S1 --> S2 --> S3 --> S4 --> S5
    end
    
    S5 -->|REJECT| END1(["End"])
    S5 -->|HOLD| S1
    S5 -->|APPROVE| PO
    
    subgraph PURCHASE["2. Purchase Phase"]
        PO["Purchase Order<br/>(gated by cupping)"]
        PO_APP["Authority Matrix<br/>Approval"]
        GR["Goods Receipt<br/>Verification"]
        ASM["Arrival Sample<br/>Match Check"]
        LOT_CREATE["✨ Generate lot_sn ✨<br/>(TRACEABILITY ANCHOR)"]
        
        PO --> PO_APP --> GR --> ASM --> LOT_CREATE
    end
    
    LOT_CREATE --> INV
    
    subgraph PRODUCTION_USE["3. Production Use"]
        INV["GreenCoffeeLot<br/>lot_sn = ABC123<br/>Status: FRESH"]
        ROAST["RoastingBatch<br/>references lot_sn"]
        QC_REC["QCTestRecord<br/>references lot_sn"]
        FG["FinishedGoodsLot<br/>references lot_sn"]
        
        INV --> ROAST --> QC_REC --> FG
    end
    
    FG --> CONSUMPTION
    
    subgraph CONSUMPTION["4. Consumption Tracking"]
        CAL["CalibrationSession<br/>references lot_sn<br/>(File 19)"]
        WASTE["CalibrationWaste<br/>references lot_sn<br/>(File 22)"]
        ORDER["SalesOrderLine<br/>references lot_sn<br/>(File 06)"]
        FIELD["FieldVisit Calibration<br/>references lot_sn<br/>(File 09)"]
        COMP["CustomerComplaint<br/>references lot_sn"]
        
        FG --> CAL
        FG --> WASTE
        FG --> ORDER
        FG --> FIELD
        FG --> COMP
    end
    
    CONSUMPTION --> END_PHASE
    
    subgraph END_PHASE["5. Lot End-of-Life"]
        DEPLETE{"Stock<br/>Depleted?"}
        EXPIRED{"Past Expiry?"}
        CLOSE["Lot Status: CLOSED<br/>History preserved permanently"]
        
        DEPLETE -->|Yes| CLOSE
        EXPIRED -->|Yes| CLOSE
    end
    
    subgraph TRACE["Forensic Query at Any Time"]
        QUERY["Query: lot_sn = ABC123"]
        RESULT["Returns:<br/>• Origin & cupping data<br/>• All roasts<br/>• All QC tests<br/>• All calibrations<br/>• All orders<br/>• All complaints<br/>• Full audit trail"]
        QUERY --> RESULT
    end
    
    style LOT_CREATE fill:#ffcc99
    style INV fill:#ccffcc
    style S3 fill:#ffaaaa
    style QUERY fill:#ccccff
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 6 — EVENT-DRIVEN INTER-MODULE COMMUNICATION
════════════════════════════════════════════════════════════════════════════════

```mermaid
graph TB
    subgraph PUBLISHERS["Event Publishers"]
        F06P["File 06<br/>Order Workflow"]
        F19P["File 19<br/>Calibration"]
        F21P["File 21<br/>QC Testing"]
        F09P["File 09<br/>Field Visits"]
        F10P["File 10<br/>Pricing"]
        F02P["File 02<br/>Accounting"]
        F03P["Files 03+04+05<br/>Coffee Lifecycle"]
        F08P["File 08<br/>Governance"]
        F12P["File 12<br/>Events/Calendar"]
        F17P["File 17<br/>HR"]
    end
    
    subgraph EVENTS["Domain Events (via Outbox Pattern)"]
        E1["OrderShipped"]
        E2["CalibrationSessionApproved"]
        E3["QCFailed"]
        E4["QCApproved"]
        E5["FieldVisitApproved"]
        E6["PriceChanged"]
        E7["DiscountActivated"]
        E8["PaymentConfirmed"]
        E9["GoodsReceived"]
        E10["AuthorityMatrixRuleChanged"]
        E11["EquipmentStatusChanged"]
        E12["PolicyPublished"]
        E13["PayrollApproved"]
        E14["TaskOverdue"]
        E15["EmployeeContractCreated"]
    end
    
    F06P -.publishes.-> E1
    F19P -.publishes.-> E2
    F21P -.publishes.-> E3
    F21P -.publishes.-> E4
    F09P -.publishes.-> E5
    F10P -.publishes.-> E6
    F10P -.publishes.-> E7
    F02P -.publishes.-> E8
    F03P -.publishes.-> E9
    F08P -.publishes.-> E10
    F12P -.publishes.-> E11
    F08P -.publishes.-> E12
    F17P -.publishes.-> E13
    F12P -.publishes.-> E14
    F17P -.publishes.-> E15
    
    EVENTS --> BUS["EventBus<br/>(Outbox + Async Delivery)"]
    
    BUS --> CONSUMERS
    
    subgraph CONSUMERS["Event Consumers"]
        C02["File 02<br/>Accounting"]
        C06["File 06<br/>Orders"]
        C03["Files 03+04+05<br/>Coffee Lifecycle"]
        C22["File 22<br/>Cal. Waste"]
        C25["File 25<br/>Recipe Library"]
        C09["File 09<br/>Field Visits"]
        C13["File 13<br/>Internal Audit"]
        C15["File 15<br/>Reports"]
        C07["File 07<br/>Dashboard"]
        C19["File 19<br/>Calibration"]
        C23["File 23<br/>Equip. Cleaning"]
        C17["File 17<br/>HR"]
        C16["File 16<br/>Sales"]
        C01["File 01<br/>User Mgmt"]
    end
    
    E1 -.COGS recognition.-> C02
    E1 -.update metrics.-> C15
    E1 -.refresh dashboard.-> C07
    E2 -.create waste record.-> C22
    E2 -.update intelligence.-> C25
    E2 -.aggregate.-> C09
    E3 -.quarantine lot.-> C03
    E3 -.may create finding.-> C13
    E4 -.batch eligible.-> C06
    E5 -.intelligence.-> C25
    E5 -.update metrics.-> C15
    E6 -.invalidate cache.-> C10P[File 10 Self]
    E6 -.notify reps.-> C16
    E8 -.confirm order.-> C06
    E8 -.update AR.-> C16
    E9 -.post AP entry.-> C02
    E10 -.invalidate cache.-> C08[File 08 Self]
    E11 -.suppress calibration.-> C19
    E11 -.suppress cleaning.-> C23
    E12 -.create acks.-> C17
    E13 -.post salary expense.-> C02
    E15 -.link user role.-> C01
    
    style BUS fill:#ffcc99
    style E1 fill:#99ccff
    style E2 fill:#99ccff
    style E3 fill:#ff9999
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 7 — SAAS MULTI-TENANT REQUEST FLOW
════════════════════════════════════════════════════════════════════════════════

```mermaid
sequenceDiagram
    autonumber
    participant Client as Client<br/>(Web/iOS/Android/Station)
    participant Gateway as API Gateway
    participant Auth as File 01<br/>Auth Service
    participant Session as Session Store
    participant Module as Operating Module
    participant Service as Service Layer
    participant DB as Database<br/>(Row-Level Security)
    participant Audit as Audit Log

    Client->>Gateway: API Request<br/>+ Bearer Token
    Gateway->>Auth: Validate token
    Auth->>Session: Lookup session
    Session-->>Auth: Session data:<br/>{user_id, tenant_id,<br/>permissions, role}
    
    alt Token invalid
        Auth-->>Client: 401 Unauthorized
    else Token valid
        Auth-->>Gateway: Authenticated context
        Gateway->>Gateway: Check rate limits<br/>per tenant
        
        alt Rate exceeded
            Gateway-->>Client: 429 Too Many Requests
        else Within limits
            Gateway->>Module: Forward request<br/>+ context
            Module->>Module: Check permission<br/>for action
            
            alt Permission denied
                Module-->>Client: 403 Forbidden
            else Permission granted
                Module->>Service: Call service method<br/>(tenant_id, ...)
                
                Note over Service,DB: tenant_id ALWAYS from session,<br/>NEVER from request payload
                
                Service->>DB: Query WHERE tenant_id = ?
                
                Note over DB: Row-Level Security<br/>enforces tenant isolation<br/>even if app code forgets WHERE
                
                DB-->>Service: Tenant-scoped data only
                Service->>Audit: Log action<br/>(synchronous, blocking)
                
                alt Audit log fails
                    Audit-->>Service: ERROR
                    Service-->>Module: ABORT
                    Module-->>Client: 500 Error
                else Audit logged
                    Audit-->>Service: OK
                    Service-->>Module: Operation result
                    Module-->>Client: 200 OK + Response
                end
            end
        end
    end
    
    Note over Client,Audit: Three layers of tenant isolation:<br/>1. App layer: tenant_id from session<br/>2. Service layer: every query scoped<br/>3. DB layer: RLS as last line of defense
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 8 — DAILY BRANCH OPERATIONS FLOW
════════════════════════════════════════════════════════════════════════════════

```mermaid
flowchart TD
    OPEN(["☀️ Branch Opens<br/>(Daily)"]) --> CHECK_IN["Barista Check-In<br/>(File 17 Attendance)"]
    
    CHECK_IN --> TASKS_GEN["DailyTaskGeneratorJob<br/>creates today's tasks"]
    
    TASKS_GEN --> MORNING_TASKS
    
    subgraph MORNING_TASKS["Morning Tasks (before service)"]
        CLEAN_EQ["Equipment Cleaning<br/>(File 23)<br/>scope=COFFEE_EQUIPMENT"]
        CLEAN_PR["Premises Cleaning<br/>(File 24)<br/>scope=PREMISES"]
        EQUIP_CHECK{"Equipment Status<br/>= ACTIVE?"}
    end
    
    CLEAN_EQ --> EQUIP_CHECK
    CLEAN_PR --> EQUIP_CHECK
    
    EQUIP_CHECK -->|UNDER_MAINTENANCE| MAINT["Defer Calibration<br/>+ Notify Manager"]
    EQUIP_CHECK -->|ACTIVE| CALIB
    
    subgraph CALIB["Calibration (File 19)"]
        CAL_START["Create CalibrationSession<br/>Snapshot Official Recipe"]
        SHOT1["Shot 1<br/>Dose/Yield/Time/TDS"]
        DIAG["ExtractionDiagnosticEngine<br/>(pure function)"]
        ADJUST{"Adjustment<br/>Needed?"}
        SHOT2["Adjust + Shot 2"]
        BEST_SHOT["Designate Best Shot"]
        SUBMIT["Submit Session"]
        
        CAL_START --> SHOT1 --> DIAG --> ADJUST
        ADJUST -->|Yes| SHOT2 --> DIAG
        ADJUST -->|No| BEST_SHOT
        BEST_SHOT --> SUBMIT
    end
    
    SUBMIT --> QM_REV{"Quality Manager<br/>Approval<br/>(or Branch Mgr<br/>per Authority Matrix)"}
    
    QM_REV -->|Rejected| SHOT1
    QM_REV -->|Approved| APPROVED["Session APPROVED<br/>Fire CalibrationSessionApproved event"]
    
    APPROVED --> PARALLEL_EFFECTS
    
    subgraph PARALLEL_EFFECTS["Parallel Event Consumers"]
        WASTE["File 22:<br/>Create CalibrationWasteRecord<br/>+ Deduct inventory<br/>+ Post Cost of Quality"]
        INTEL["File 25:<br/>Update Recipe Intelligence<br/>(nightly aggregation)"]
        REPORT["File 15:<br/>Update calibration<br/>compliance metric"]
    end
    
    PARALLEL_EFFECTS --> SERVICE_BEGINS(["☕ Service Begins"])
    
    SERVICE_BEGINS --> DURING_SERVICE
    
    subgraph DURING_SERVICE["During Service Hours"]
        ORDERS["Customer Orders<br/>(via POS / File 06)"]
        RECURRING_CLEAN["Recurring Cleaning Tasks<br/>(every 2 hours)"]
        QUALITY_CHECK["Periodic Quality Checks"]
        WALK_INS["Walk-in / Mystery Shopper<br/>(File 09)"]
    end
    
    DURING_SERVICE --> SHIFT_END
    
    subgraph SHIFT_END["End of Shift / Closing"]
        FINAL_CLEAN["Final Cleaning Tasks"]
        SHIFT_OUT["Shift Check-Out<br/>(File 17)"]
        CASH["Cash Reconciliation"]
        REPORT_GEN["Daily Operations Report"]
        COMPLIANCE_CHECK["Compliance Rule:<br/>CR-002 evaluated<br/>(calibration compliance)"]
    end
    
    SHIFT_END --> CLOSE(["🌙 Branch Closes"])
    
    style CAL_START fill:#ffcc99
    style APPROVED fill:#99ff99
    style WASTE fill:#ffaaaa
    style COMPLIANCE_CHECK fill:#ccccff
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 9 — DATA & DECISION FLOW (KEY DECISION POINTS)
════════════════════════════════════════════════════════════════════════════════

```mermaid
flowchart TD
    REQ([Incoming Request]) --> Q1{"1. Tenant<br/>Active?"}
    Q1 -->|No| BLOCK1[Block + Notify]
    Q1 -->|Yes| Q2
    
    Q2{"2. Subscription<br/>Valid?"} -->|No| BLOCK2[Restrict Features]
    Q2 -->|Yes| Q3
    
    Q3{"3. User has<br/>Tenant Membership?"} -->|No| BLOCK3[401 Unauthorized]
    Q3 -->|Yes| Q4
    
    Q4{"4. User has<br/>Required Permission?"} -->|No| BLOCK4[403 Forbidden]
    Q4 -->|Yes| Q5
    
    Q5{"5. Action requires<br/>Approval?"} -->|No| EXEC[Execute Action]
    Q5 -->|Yes| Q6
    
    Q6["6. Lookup Authority Matrix<br/>per action_type + value"] --> Q7
    
    Q7{"7. Self-approval<br/>allowed?"} -->|No - user is approver| BLOCK5[Reject:<br/>Self-approval blocked]
    Q7 -->|OK| Q8
    
    Q8["8. Route to Approver<br/>+ Notify"] --> Q9{"9. Approver<br/>decides"}
    
    Q9 -->|Reject| BLOCK6[Action blocked<br/>+ Reason logged]
    Q9 -->|Approve| Q10
    
    Q10{"10. Dual Approval<br/>Required?"} -->|Yes| Q11{"11. Second<br/>Approver"}
    Q10 -->|No| EXEC
    Q11 -->|Reject| BLOCK6
    Q11 -->|Approve| EXEC
    
    EXEC --> Q12{"12. Is this an<br/>Order Shipment?"}
    Q12 -->|Yes| COGS[Post COGS<br/>Master Invariant 5]
    Q12 -->|No| Q13
    
    Q13{"13. Is this a<br/>Calibration Approval?"} -->|Yes| WASTE[Fire CalibrationWasteDeduction]
    Q13 -->|No| Q14
    
    Q14{"14. Is this a QC<br/>FAIL decision?"} -->|Yes| QUAR[Atomic Quarantine<br/>+ Mark Lot UNDER_INVESTIGATION]
    Q14 -->|No| Q15
    
    Q15{"15. Is this a<br/>Posted Financial Entry?"} -->|Yes| Q16{"16. Within<br/>tenant scope?"}
    Q15 -->|No| Q17
    Q16 -->|No| ALERT1[CRITICAL ALERT<br/>Cross-tenant attempt]
    Q16 -->|Yes| LOG_FIN[Log to Financial Audit]
    
    Q17{"17. Touches Inventory?"} -->|Yes| Q18{"18. Sample Roast<br/>(sample_roast=true)?"}
    Q17 -->|No| AUDIT_LOG
    Q18 -->|Yes - block deduction| AUDIT_LOG[Log to AuditLog<br/>Master Invariant 4]
    Q18 -->|No - normal flow| DEDUCT[Deduct from Inventory] --> AUDIT_LOG
    
    COGS --> AUDIT_LOG
    WASTE --> AUDIT_LOG
    QUAR --> AUDIT_LOG
    LOG_FIN --> AUDIT_LOG
    
    AUDIT_LOG --> DONE([Action Complete])
    
    style Q5 fill:#ffcc99
    style Q6 fill:#ff9999
    style Q14 fill:#ffaaaa
    style Q18 fill:#ffcc99
    style AUDIT_LOG fill:#ccccff
    style EXEC fill:#99ff99
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 10 — IMPLEMENTATION DEPENDENCY GRAPH
════════════════════════════════════════════════════════════════════════════════

```mermaid
graph TD
    P0([Phase 0: Foundations])
    
    P0 --> P0_1["0.1 Infrastructure<br/>+ Module Boundary Linter"]
    P0_1 --> P0_2["0.2 File 01<br/>Login & Access"]
    P0_2 --> P0_3["0.3 File B Infra<br/>EventBus, AuditLog,<br/>Notifications, FeatureFlags"]
    P0_3 --> P0_4["0.4 File 08 Partial<br/>Authority Matrix"]
    P0_4 --> P0_5["0.5 File 02 Partial<br/>Chart of Accounts<br/>+ Journal Entry"]
    
    P0_5 --> P1([Phase 1: Core Operations])
    
    P1 --> P1_1["1.1 Files 03+04+05<br/>Coffee Lifecycle<br/>(lot_sn)"]
    P1 --> P1_2["1.2 File 25<br/>Recipe Library"]
    P1_2 --> P1_3["1.3 File 10<br/>Pricing"]
    P1_3 --> P1_4["1.4 File 16<br/>Sales"]
    P1_4 --> P1_5["1.5 File 06<br/>Order Workflow"]
    P1_5 --> P1_6["1.6 File 02 Full<br/>Accounting"]
    P1_1 --> P1_7["1.7 Inventory<br/>+ File 20 Count"]
    P1_6 --> P1_7
    P1_7 --> P1_8["1.8 File 17<br/>HR"]
    
    P1_8 --> P2([Phase 2: Quality & Operations])
    
    P2 --> P2_1["2.1 File 19<br/>Daily Calibration"]
    P2_1 --> P2_2["2.2 File 22<br/>Calibration Waste"]
    P2 --> P2_3["2.3 File 21<br/>QC Testing"]
    P2 --> P2_4["2.4 File 12<br/>Events + Equipment Registry"]
    P2_4 --> P2_5["2.5 Files 23 + 24<br/>Cleaning Modules"]
    P2_1 --> P2_6["2.6 File 09<br/>Field Visits"]
    P2_2 --> P2_6
    
    P2_6 --> P3([Phase 3: Governance & Visibility])
    
    P3 --> P3_1["3.1 File 08 Full<br/>Governance"]
    P3 --> P3_2["3.2 File 15<br/>Reports Center"]
    P3_2 --> P3_3["3.3 File 07<br/>Executive Dashboard"]
    P3_1 --> P3_4["3.4 File 13<br/>Internal Audit"]
    
    P3_4 --> P4([Phase 4: Commercial & Strategic])
    
    P4 --> P4_1["4.1 File 14<br/>Marketing"]
    P4 --> P4_2["4.2 File 11<br/>Analytics"]
    P4 --> P4_3["4.3 File 18<br/>OKR / Strategic"]
    P4_2 --> P4_4["4.4 File 09 Phase 2<br/>Mystery Shopper +<br/>Recipe Intelligence"]
    
    P4_4 --> P5([Phase 5: AI & Integrations])
    
    P5 --> P5_1["5.1 File A Phase 1<br/>AI Advisory"]
    P5_1 --> P5_2["5.2 File A Phase 2<br/>Read-Only Agent"]
    P5 --> P5_3["5.3 External Integrations<br/>Foodics, Qoyod, ZATCA"]
    
    style P0 fill:#ffcccc
    style P1 fill:#ffccaa
    style P2 fill:#ffeeaa
    style P3 fill:#ccffcc
    style P4 fill:#ccccff
    style P5 fill:#ddccff
    style P0_4 fill:#ff9999
    style P1_3 fill:#99ccff
    style P1_2 fill:#ffcc99
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 11 — REPORTS / DASHBOARD / ANALYTICS CONSISTENCY
════════════════════════════════════════════════════════════════════════════════

```mermaid
graph LR
    subgraph SOURCES["Operational Modules (Truth)"]
        F02M["File 02<br/>Accounting<br/>POSTED only"]
        F06M["File 06<br/>Orders<br/>COMPLETED only"]
        F16M["File 16<br/>Sales"]
        F21M["File 21<br/>QC"]
        F19M["File 19<br/>Calibration<br/>APPROVED only"]
        F09M["File 09<br/>Visits<br/>APPROVED only"]
        F17M["File 17<br/>HR"]
    end
    
    subgraph SERVICE_LAYER["Service Layer (Single Source of Truth)"]
        ACC_SVC["AccountingService<br/>.getRevenue()<br/>.getExpenses()<br/>.getCOGS()"]
        ORD_SVC["OrderService<br/>.getCompletedOrders()<br/>.getAOV()"]
        SALES_SVC["SalesService<br/>.getCustomerMetrics()"]
        QC_SVC["QCService<br/>.getPassRate()"]
        CAL_SVC["CalibrationService<br/>.getCompliance()"]
        VISIT_SVC["VisitService<br/>.getQualityScore()"]
        HR_SVC["HRService<br/>.getAttendanceRate()"]
    end
    
    F02M --> ACC_SVC
    F06M --> ORD_SVC
    F16M --> SALES_SVC
    F21M --> QC_SVC
    F19M --> CAL_SVC
    F09M --> VISIT_SVC
    F17M --> HR_SVC
    
    subgraph CONSUMERS["Three Read Consumers"]
        F15C["File 15<br/>Reports Center<br/>(formal periodic)"]
        F07C["File 07<br/>Executive Dashboard<br/>(real-time)"]
        F11C["File 11<br/>Analytics Tools<br/>(interactive)"]
    end
    
    SERVICE_LAYER --> F15C
    SERVICE_LAYER --> F07C
    SERVICE_LAYER --> F11C
    
    F15C -.same period<br/>same filters.-> F07C
    F07C -.same period<br/>same filters.-> F11C
    
    F15C -.SHOULD MATCH.-> CHECK
    F07C -.SHOULD MATCH.-> CHECK
    F11C -.SHOULD MATCH.-> CHECK
    
    CHECK{"Integration Test in CI:<br/>Reports value == Dashboard value<br/>== Analytics value?"}
    
    CHECK -->|Match| PASS([✓ Master Invariant 9 OK])
    CHECK -->|Diverge| FAIL([✗ BUG — Block Deploy])
    
    style SERVICE_LAYER fill:#ffcc99
    style CHECK fill:#ccccff
    style PASS fill:#99ff99
    style FAIL fill:#ff9999
```



════════════════════════════════════════════════════════════════════════════════
              DIAGRAM 12 — 15 MASTER INVARIANTS (REFERENCE MAP)
════════════════════════════════════════════════════════════════════════════════

```mermaid
mindmap
  root((15 Master<br/>Invariants))
    Tenant Isolation
      INV-01: tenant_id on every entity
      INV-02: No hard deletes (soft only)
    Audit & Integrity
      INV-03: AuditLog INSERT-only
      INV-07: POSTED-only for finance
      INV-08: COMPLETED-only for production
    Coffee Lifecycle
      INV-04: Sample ≠ Inventory
      INV-06: Transformation ≠ Production
      INV-12: lot_sn anchors traceability
      INV-13: Official Recipe immutable
    Financial Accuracy
      INV-05: COGS at shipment only
      INV-10: PriceResolution is only source
      INV-15: Negative net blocks payroll
    Approval & Governance
      INV-11: Authority Matrix runtime-enforced
      INV-14: QM gate for external reports
    Consistency
      INV-09: Dashboard = Reports = Analytics
```



════════════════════════════════════════════════════════════════════════════════
              HOW TO RENDER THESE DIAGRAMS
════════════════════════════════════════════════════════════════════════════════

OPTION 1 — Online (no install):
  Visit https://mermaid.live/
  Paste any diagram block (the content between ```mermaid and ```)
  See it rendered instantly. Export as PNG or SVG.

OPTION 2 — GitHub:
  Mermaid diagrams render natively in GitHub markdown.
  Save a .md file with these diagrams; view on GitHub.

OPTION 3 — VS Code:
  Install extension "Markdown Preview Mermaid Support"
  Open this file as .md; use Markdown preview.

OPTION 4 — Notion:
  Create a code block with language "mermaid"
  Paste the diagram.

OPTION 5 — Documentation tools:
  GitBook, Confluence, ReadTheDocs all support Mermaid.



════════════════════════════════════════════════════════════════════════════════
                          END OF DIAGRAMS DOCUMENT
                                                                                
        12 comprehensive diagrams covering all major system aspects:           
                                                                                
        1.  High-Level System Architecture                                      
        2.  End-to-End Workflow (English)                                       
        3.  End-to-End Workflow (Arabic)                                        
        4.  Authority Matrix Approval Flow                                      
        5.  Coffee Lifecycle with lot_sn Traceability                          
        6.  Event-Driven Inter-Module Communication                            
        7.  SaaS Multi-Tenant Request Flow                                      
        8.  Daily Branch Operations Flow                                        
        9.  Data & Decision Flow (Key Decision Points)                         
        10. Implementation Dependency Graph                                     
        11. Reports / Dashboard / Analytics Consistency                         
        12. 15 Master Invariants Reference Map                                  
                                                                                
════════════════════════════════════════════════════════════════════════════════
